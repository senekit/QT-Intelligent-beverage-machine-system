#include "drinkwidget.h"
#include<QGridLayout>
#include<QDebug>

/**
 * @method drinkwidget
 * @for  drinkwidget
 * @param {int ,Qwidget}idOfwidget 饮料的id，parent 父窗口
 * @return {}
 * @brief   构造一个drinkwidget窗口，根据饮料的id确定位置
 */
drinkwidget::drinkwidget(int idOfWidget,QWidget* parent):QWidget(parent)
{

    this->drinkOfWidget =new drink(idOfWidget);

    nameOfDrink = new QLabel(this);
    nameOfDrink->setText("   名称："+(this->drinkOfWidget->name));
    nameOfDrink->setStyleSheet("font: 75 10pt '微软雅黑'; border-radius:5px;  "
                               "background-color:qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(100, 253, 240, 255), stop:1 rgba(29, 111, 163, 255)); ");

    quanityOfWidget = new QLabel(this);
    quanityOfWidget->setText("   剩余："+QString::number(this->drinkOfWidget->remainingQuanity));
    quanityOfWidget->setStyleSheet("font: 75 10pt '微软雅黑'; border-radius:5px; "
                                   " background-color:qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(67, 203, 255, 255), stop:0.977528 rgba(151, 8, 204, 255), stop:1 rgba(18, 53, 151, 255));");

    priceOfWidget = new QLabel(this);
    priceOfWidget->setText("   价格："+QString::number(this->drinkOfWidget->price));
    priceOfWidget->setStyleSheet("font: 75 10pt '微软雅黑'; border-radius:5px; "
                                   " background-color:qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(206, 159, 252, 255), stop:1 rgba(115, 103, 240, 255));");

    QLabel *tipsOfBuy = new QLabel(this);
    tipsOfBuy->setText(" 购买:");
    tipsOfBuy->setStyleSheet("font: 75 10pt '微软雅黑'; border-radius:3px; "
                                   " background-color:qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(171, 220, 255, 255), stop:1 rgba(3, 150, 255, 255))");

    if(this->drinkOfWidget->remainingQuanity<=0)
    {
        this->drinkOfWidget->isSale = false;
    }
    qDebug()<<this->drinkOfWidget->remainingQuanity;
    QLabel *picOfDrink = new QLabel(this);
    QPixmap *pix = new QPixmap(":/new/drinks/images/"+QString::number(this->drinkOfWidget->id)+".png");
    picOfDrink->setPixmap(pix->scaled(200,200));
    int temp = this->drinkOfWidget->id-1;
    picOfDrink->setGeometry((temp%3)*300,((temp/3))*300,200,200);
    nameOfDrink->setGeometry((temp%3)*300+25,((temp/3))*300+200,150,20);
    quanityOfWidget->setGeometry((temp%3)*300+25,((temp/3))*300+220,150,20);
    priceOfWidget->setGeometry((temp%3)*300+25,((temp/3))*300+240,150,20);
    tipsOfBuy->setGeometry((temp%3)*300+40,((temp/3))*300+260,50,20);
 //   numberOfBuy->setGeometry((temp%3)*300+100,((temp/3))*300+260,50,20);
}

drinkwidget::drinkwidget(QWidget *parent):QWidget(parent)
{
//nothing to do
}
drinkwidget::drinkwidget()
{
//nothing to do
}
drinkwidget::~drinkwidget()
{
//nothing to do
}

/**
 * @method changeNumber
 * @for drinkwidget
 * @param{int}number 对数据库的修改量
 * @return {void}
 * @brief   修改饮料库存
 */
void drinkwidget::changeNumber(int number)
{
    qDebug()<<number;
    this->drinkOfWidget->change(number);
    this->quanityOfWidget->setText("剩余："+QString::number(this->drinkOfWidget->remainingQuanity));
}


