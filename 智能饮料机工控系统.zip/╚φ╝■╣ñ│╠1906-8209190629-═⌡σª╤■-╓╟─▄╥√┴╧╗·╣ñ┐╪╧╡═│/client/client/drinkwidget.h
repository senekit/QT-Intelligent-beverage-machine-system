#ifndef DRINKWIDGET_H
#define DRINKWIDGET_H
#include"drink.h"
#include<QWidget>
#include<QLabel>
#include<QString>
#include<QPushButton>
#include<QLineEdit>
#include<QComboBox>
#include<QSpinBox>
#include<QPixmap>


/**
* @projectName   client
* @class         drinkwidget
* @version     v1.1.0
* @brief         Beverage window, display beverage information such as inventory, price, etc
* @author      senekit
* @date          2020-07-08
*/

class drinkwidget:public QWidget
{
public:
    drinkwidget();
    drinkwidget(QWidget *parent = nullptr);
    drinkwidget(int idOfWidget,QWidget *parent = nullptr);
    ~drinkwidget();
    QLabel *quanityOfWidget;
    QLabel *nameOfDrink;
    QLabel *priceOfWidget;
//    QSpinBox *numberOfBuy;
    drink *drinkOfWidget;
public slots:
    void changeNumber(int number);
};

#endif // DRINKWIDGET_H
