#include "widget.h"
#include "ui_widget.h"
#include"drink.h"
#include<QImage>
#include<QLabel>
#include"drinkwidget.h"
#include<QGridLayout>
#include<QPalette>
#include<QDebug>
#include<QStatusBar>
#include<QMessageBox>
#include<QDateTime>
#include"reswidget.h"
#include"tcp_client.h"
#include"paywidget.h"
#include<QSqlDatabase>
#include<QTextCodec>
#include<QSqlQuery>
#include<QSqlTableModel>
#include<QTableView>
#include<QMediaPlayer>
/**
 * @method Widget
 * @for Widget
 * @param{QWidget}parent 父窗口
 * @return {}
 * @brief   购买窗口，实现主要功能
 */

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{

    p = new TCP_Client(nullptr);
    //p->show();
    p->hide();
    this->setWindowTitle("client");
    sigin = new ResWidget(nullptr);
    sigin->setWindowTitle("登陆");
    sigin->show();
    connect(sigin,SIGNAL(signIninformation(QString)),p,SLOT(slot_sendmessage1(QString)));
    connect(this,SIGNAL(RechargeOfUser(QString)),p,SLOT(slot_sendmessage1(QString)));
    connect(this,SIGNAL(reminderOfRe(QString)),p,SLOT(slot_sendmessage1(QString)));
    connect(this,SIGNAL(drinksOfBuy(QString)),p,SLOT(slot_sendmessage1(QString)),Qt::QueuedConnection);
    connect(p,SIGNAL(informationOfServer(QString )),this,SLOT(changeDb(QString)));
     drinkwidget *drink[10];
    for(int i=1;i<=6;i++)
    {
        drink[i]=new drinkwidget(i,this);
       // this->drink[i]->setStyleSheet("border-radius:10px; background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0.0335196 rgba(194, 255, 216, 255), stop:1 rgba(70, 94, 251, 255));" );
        this->numberOfBuy[i]=0;
        this->pirceOfDrinks[i]=drink[i]->drinkOfWidget->price;
        this->tempOfDrinks[i]=drink[i]->drinkOfWidget->remainingQuanity;
    }
    connect(this,&Widget::numberOfChange1,drink[1],&drinkwidget::changeNumber,Qt::QueuedConnection);
    connect(this,&Widget::numberOfChange2,drink[2],&drinkwidget::changeNumber,Qt::QueuedConnection);
    connect(this,&Widget::numberOfChange3,drink[3],&drinkwidget::changeNumber,Qt::QueuedConnection);
    connect(this,&Widget::numberOfChange4,drink[4],&drinkwidget::changeNumber,Qt::QueuedConnection);
    connect(this,&Widget::numberOfChange5,drink[5],&drinkwidget::changeNumber,Qt::QueuedConnection);
    connect(this,&Widget::numberOfChange6,drink[6],&drinkwidget::changeNumber,Qt::QueuedConnection);

    this->mode= normal;
    this->tempature = 20;
    sumOfMoney = 0;
   //int x = spinbox[1]->value();
 //  QStatusBar *statusOfuser = new QStatusBar(this);
   QLabel *status = new QLabel(this);
//   userName = "jojo";
//   userMoney = 10;
   //this-?->setText("用户:"+userName+"    余额:"+QString::number( userMoney)+"       温度："+QString::number(this->tempature));
//   statusOfuser->addWidget(status);
  // statusOfuser->setGeometry(0,650,700,50);

   ui->setupUi(this);
   // spinbox range 0 to remainingQuanity
   ui->spinBox->setRange(0,drink[1]->drinkOfWidget->remainingQuanity);
   ui->spinBox_2->setRange(0,drink[2]->drinkOfWidget->remainingQuanity);
   ui->spinBox_3->setRange(0,drink[3]->drinkOfWidget->remainingQuanity);
   ui->spinBox_4->setRange(0,drink[4]->drinkOfWidget->remainingQuanity);
   ui->spinBox_5->setRange(0,drink[5]->drinkOfWidget->remainingQuanity);
   this->ui->spinBox_6->setRange(0,drink[6]->drinkOfWidget->remainingQuanity);
   this->ui->statusLabel->setText("用户："+userName+"       余额："+QString::number(userMoney)+
                                  "       温度："+QString::number(this->tempature)
                                  + "℃       应付："+QString::number(sumOfMoney));
   this->hide();
}
Widget::~Widget()
{
    delete ui;
}

/**
 * @method on_spinBox_valueChanged
 * @for Widget
 * @param{int}ar1 主页面显示饮料购买的数量
 * @return {void}
 * @brief   对购买饮料数量实时修改
 */

void Widget::on_spinBox_valueChanged(int arg1)
{
    qDebug()<<arg1;
    sumOfMoney  -= numberOfBuy[1]*(pirceOfDrinks[1]);
    sumOfMoney +=arg1*(this->pirceOfDrinks[1]);
    numberOfBuy[1]=arg1;
    this->ui->statusLabel->setText("用户："+userName+"       余额："+QString::number(userMoney)+
                                   "       温度："+QString::number(this->tempature) + "℃       应付："+QString::number(sumOfMoney));
    update();
}

void Widget::on_spinBox_2_valueChanged(int arg1)
{
    sumOfMoney  -= numberOfBuy[2]*(pirceOfDrinks[2]);
    sumOfMoney +=arg1*(this->pirceOfDrinks[2]);
    numberOfBuy[2]=arg1;
    this->ui->statusLabel->setText("用户："+userName+"       余额："+QString::number(userMoney)+
                                   "       温度："+QString::number(this->tempature)
                                   + "℃       应付："+QString::number(sumOfMoney));
}

void Widget::on_spinBox_3_valueChanged(int arg1)
{
    sumOfMoney  -= numberOfBuy[3]*(pirceOfDrinks[3]);
    sumOfMoney +=arg1*(this->pirceOfDrinks[3]);
    numberOfBuy[3]=arg1;
    this->ui->statusLabel->setText("用户："+userName+"       余额："+QString::number(userMoney)+
                                   "       温度："+QString::number(this->tempature)
                                   + "℃       应付："+QString::number(sumOfMoney));
}

void Widget::on_spinBox_4_valueChanged(int arg1)
{
    sumOfMoney  -= numberOfBuy[4]*(pirceOfDrinks[4]);
    sumOfMoney +=arg1*(this->pirceOfDrinks[4]);
    numberOfBuy[4]=arg1;
    this->ui->statusLabel->setText("用户："+userName+"       余额："+QString::number(userMoney)+
                                   "       温度："+QString::number(this->tempature)
                                   + "℃       应付："+QString::number(sumOfMoney));
}

void Widget::on_spinBox_5_valueChanged(int arg1)
{
    sumOfMoney  -= numberOfBuy[5]*(pirceOfDrinks[5]);
    sumOfMoney +=arg1*(this->pirceOfDrinks[5]);
    numberOfBuy[5]=arg1;
    this->ui->statusLabel->setText("用户："+userName+"       余额："+QString::number(userMoney)+
                                   "       温度："+QString::number(this->tempature)
                                   + "℃       应付："+QString::number(sumOfMoney));
}

void Widget::on_spinBox_6_valueChanged(int arg1)
{
    sumOfMoney  -= numberOfBuy[6]*(pirceOfDrinks[6]);
    sumOfMoney +=arg1*(this->pirceOfDrinks[6]);
    numberOfBuy[6]=arg1;
    this->ui->statusLabel->setText("用户："+userName+"       余额："+QString::number(userMoney)+
                                   "       温度："+QString::number(this->tempature)
                                   + "℃       应付："+QString::number(sumOfMoney));
}

/**
 * @method on_pushButton_2_clicked()
 * @for Widget
 * @param{}
 * @return {void}
 * @brief  实现购买操作
 */

void Widget::on_pushButton_2_clicked()
{
    bool tag = true;
    for(int i =1;i<=6;i++)
        if(numberOfBuy[i]!=0)
            tag= false;
    if(tag)return;

    if(sumOfMoney>userMoney)
    {
        QMessageBox::information(this,"购买失败","账户余额不足，请先充值",
                              QMessageBox::Close);
    }
    else
    {
        QString str="B/";
        str = str+userName+"/";
        QDateTime datetime = QDateTime::currentDateTime();
        str = str+datetime.toString("yyyy-M-dd-hh:mm:ss");

        for(int i=1;i<=6;i++)
        {
            str  = str+"/"+QString::number(this->numberOfBuy[i]);
            if(i==1&&numberOfBuy[i]!=0){
                emit numberOfChange1((numberOfBuy[i])*(-1));
                this->tempOfDrinks[1]-=numberOfBuy[1];
                this->ui->spinBox->setRange(0,tempOfDrinks[1]);
                 numberOfBuy[i]=0;
            }
            if(i==2&&numberOfBuy[i]!=0){
                emit numberOfChange2((numberOfBuy[i])*(-1));
                this->tempOfDrinks[2]-=numberOfBuy[2];
                this->ui->spinBox_2->setRange(0,tempOfDrinks[2]);
                 numberOfBuy[i]=0;
            }
            if(i==3&&numberOfBuy[i]!=0){
                emit numberOfChange3((numberOfBuy[i])*(-1));
                this->tempOfDrinks[3]-=numberOfBuy[3];
                this->ui->spinBox_3->setRange(0,tempOfDrinks[3]);
                 numberOfBuy[i]=0;
            }
            if(i==4&&numberOfBuy[i]!=0){
                emit numberOfChange4((numberOfBuy[i])*(-1));
                this->tempOfDrinks[4]-=numberOfBuy[4];
                this->ui->spinBox_4->setRange(0,tempOfDrinks[4]);
                 numberOfBuy[i]=0;
            }
            if(i==5&&numberOfBuy[i]!=0){
                emit numberOfChange5((numberOfBuy[i])*(-1));
                this->tempOfDrinks[5]-=numberOfBuy[5];
                this->ui->spinBox_5->setRange(0,tempOfDrinks[5]);
                 numberOfBuy[i]=0;
            }
            if(i==6&&numberOfBuy[i]!=0){
                emit numberOfChange6((numberOfBuy[i])*(-1));
                this->tempOfDrinks[6]-=numberOfBuy[6];
                this->ui->spinBox_6->setRange(0,tempOfDrinks[6]);
                numberOfBuy[i]=0;
            }
        }
        str=str+"/"+QString::number(this->tempature)+"/"+QString::number(this->sumOfMoney);
        userMoney -= sumOfMoney;
        QString sta=  QString("用户："+userName+"       余额："+QString::number(userMoney)+
                                       "       温度："+QString::number(this->tempature)
                                       + "℃       应付："+QString::number(sumOfMoney));
        this->ui->statusLabel->setText(sta);
        this->ui->spinBox->setValue(0);
        this->ui->spinBox_2->setValue(0);
        this->ui->spinBox_3->setValue(0);
        this->ui->spinBox_4->setValue(0);
        this->ui->spinBox_5->setValue(0);
        this->ui->spinBox_6->setValue(0);
        this->sumOfMoney = 0;
        update();
        emit drinksOfBuy(str);
    }

}

void Widget::reminder()
{
    bool tag =  false;
    QString nameList ="Replenishment";
    for(int i =1;i<=6;i+=1)
    if(tempOfDrinks[i]==0)
    {
        tag = true;
        nameList = nameList+"/drink"+QString::number(i);
    }
    if(tag)
    {
        emit reminderOfRe(nameList);
    }
    return;
}

//支付页面
void Widget::on_pushButton_clicked()
{
//    QWidget *payWidget =new QWidget();
//    payWidget->resize(700,750);
//    QLabel * description = new QLabel(payWidget);
//    description->setText("少年！你渴望力量吗！");
//    description->setGeometry(275,700,200,50);
//    QLabel *picOfDrink = new QLabel(payWidget);
//    QPixmap *pix = new QPixmap(":/new/drinks/images/pay.png");
//    picOfDrink->setPixmap(pix->scaled(700,700));
//    payWidget->show();
    PayWidget *   payWidget = new PayWidget(nullptr);
    payWidget->setWindowTitle("少年！你渴望力量吗");
    //payWidget->resize(700,700);
    payWidget->show();
    connect(payWidget,SIGNAL(RechargeInformation(QString)),this,SLOT(changeQuanit(QString)));
}

// 更改余额
void Widget::changeQuanit(QString information)
{
    QString str  = "RE/"+userName+"/"+information;
    userMoney+=information.toInt();
    this->ui->statusLabel->setText("用户："+userName+"       余额："+QString::number(userMoney)+
                                   "       温度："+QString::number(this->tempature)
                                   + "℃       应付："+QString::number(sumOfMoney));
    emit RechargeOfUser(str);
}

/**
 * @method changeDb
 * @for WIdget
 * @param{QString}information 服务器传来的信息
 * @return {void}
 * @brief   通过字符串首个子串，确定信息的类比
 */

void Widget::changeDb(QString information)
{
    QStringList array  = information.split("/");
    if(array[0]=="T")this->changeTemperature(array[1]);
    if(array[0]=="F")this->failToSignIn();
    if(array[0]=="S")this->successSignIn(array);
    if(array[0]=="SR")this->successRes(array);
    if(array[0]=="FR")this->failToRes(array);
}

//改变温度
void Widget::changeTemperature(QString temperature)
{
    this->tempature = temperature.toInt();
    this->ui->statusLabel->setText("用户："+userName+"       余额："+QString::number(userMoney)+
                                   "       温度："+QString::number(this->tempature)
                                   + "℃       应付："+QString::number(sumOfMoney));
    update();
}

//登入失败
void Widget::failToSignIn()
{
     QMessageBox::warning(this,"登陆失败","账号不存在或密码错误!",QMessageBox::Ok);
}

//成功登入
void Widget::successSignIn(QStringList array)
{
    this->userName = array[1];
    this->userMoney = array[2].toInt();
    this->ui->statusLabel->setText("用户:"+userName+"    余额:"+QString::number( userMoney)+"       温度："+QString::number(this->tempature));
    this->sigin->hide();
    this->sigin->userName->clear();
    this->sigin->password->clear();
    this->show();
    this->reminder();
    QMediaPlayer*  player = new QMediaPlayer;
    connect(player, SIGNAL(positionChanged(qint64)), this, SLOT(positionChanged(qint64)));
    player->setMedia(QUrl::fromLocalFile("D:\\drinks\\client\\images\\pkq.mp3"));
    player->setVolume(30);
    player->play();

}

//注册成功
void Widget::successRes(QStringList array)
{
       if(array[0]=="FR")return;
       QMessageBox::about(this,"成功","账号注册成功!");
       this->userName = array[1];
       this->userMoney = array[2].toInt();
       this->ui->statusLabel->setText("用户:"+userName+"    余额:"+QString::number( userMoney)+"       温度："+QString::number(this->tempature));
       this->sigin->close();
       this->show();
}

//注册失败
void Widget::failToRes(QStringList array)
{
    array[0];
    this->sigin->password->clear();
     QMessageBox::warning(this,"注册失败","账号已存在!",QMessageBox::Ok);
}

//补货
void Widget::on_pushButton_3_clicked()
{
    if(userName!="1")return;
    QWidget*  wid = new QWidget(nullptr);
    QSqlTableModel *model =new QSqlTableModel(wid);
    QTableView* view =new QTableView(wid);
    wid->resize(520,285);
    view->resize(700,700);
    model->setTable("drinks");
    model->select();
    wid->show();
    view->setModel(model);
}

void Widget::on_pushButton_4_clicked()
{
    this->close();
   // this->hide();
//    this->sigin->show();
}
