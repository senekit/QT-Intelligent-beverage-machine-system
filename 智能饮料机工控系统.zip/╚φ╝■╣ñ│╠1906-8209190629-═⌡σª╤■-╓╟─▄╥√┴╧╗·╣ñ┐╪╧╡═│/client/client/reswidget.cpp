#include "reswidget.h"
#include "ui_reswidget.h"
#include<QGridLayout>
#include<QMessageBox>
/**
 * @method ResWidget
 * @for ResWidget
 * @param{QWidget}parent  父窗口
 * @return {}
 * @brief 创建登陆页面
 */

ResWidget::ResWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ResWidget)
{
    ui->setupUi(this);
    userName = new QLineEdit(this);
    password  = new QLineEdit(this);
    userName->setGeometry(130,40,120,25);
    password->setGeometry(130,70,120,25);
}

ResWidget::~ResWidget()
{
    delete ui;
}

void ResWidget::on_pushButton_clicked()
{
    QString str = "S/"+this->userName->text()+"/"+this->password->text();
    emit signIninformation(str);
}

/**
 * @method  pushButton_2_clicked()
 * @for  ResWidget
 * @param{}
 * @return {void }
 * @brief  注册账户
 */

void ResWidget::on_pushButton_2_clicked()
{
    if(this->userName->text()==""||this->password->text()=="")
    {
            QMessageBox::warning(this,"注册失败","账户密码不能为空!",QMessageBox::Ok);
            return;
    }
    QString str = "R/"+this->userName->text()+"/"+this->password->text();
    emit signIninformation(str);
}
