#ifndef TCP_CLIENT_H
#define TCP_CLIENT_H

#include <QWidget>
#include <QTcpSocket>

/**
* @projectName   client
* @class         tcp_client
* @version     v2.0.0
* @brief         Design TCP_ Client , which can send and receive information from the server
* @author      senekit
* @date          2020-07-10
*/

namespace Ui {
class TCP_Client;
}

class TCP_Client : public QWidget
{
    Q_OBJECT

public:
    explicit TCP_Client(QWidget *parent = nullptr);
    ~TCP_Client();
signals:
    void informationOfServer(QString inforamtion);
//与按钮交互，故函数都设置为槽函数
private slots:
    void slot_connected(); //处理成功连接到服务器的槽
    void slot_sendmessage(); //发送消息到服务器的槽
     void slot_sendmessage1(QString item);
    void slot_recvmessage(); //接收来自服务器的消息的槽
    void slot_disconnect(); //取消与服务器连接的槽

private:
    Ui::TCP_Client *ui;

    bool isconnetion; //判断是否连接到服务器的标志位
    QTcpSocket *TCP_sendMesSocket; //发送消息套接字
};

#endif // TCP_CLIENT_H
