#ifndef CONNECTION_H
#define CONNECTION_H
#include<QMessageBox>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QDebug>

/**
* @projectName   client
* @class         connection
* @version     v1.4.0
* @brief         connect to database
* @author      senekit
* @date         2020-07-09
*/

static bool creatConnection()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("drink.db");
    if(!db.open())
    {
            QMessageBox::critical(0,"can`t open database","unable to establish a database connection",
                                  QMessageBox::Cancel);
            return  false;
     }
            QSqlQuery query;
       query.exec(QString("create table drinks(id int primary key,""name varchar,price int,"
                               "remainingQuantity int)"));
            return  true;;
}
#endif // CONNECTION_H
