#include "widget.h"
#include"connection.h"
#include <QApplication>
#include"drinkwidget.h"
#include"tcp_client.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    if(!creatConnection())return 1;
    Widget *w = new Widget(0);
  //  w->show();
//    TCP_Client p;
//    p.show();
  //  t1.show();
    return a.exec();
}
