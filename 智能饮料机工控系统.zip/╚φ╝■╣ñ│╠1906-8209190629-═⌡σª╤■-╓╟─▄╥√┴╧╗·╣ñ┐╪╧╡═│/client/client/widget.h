#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include"drinkwidget.h"
#include"reswidget.h"
#include"tcp_client.h"
#include<QLabel>

/**
* @projectName   client
* @class         Widget
* @version     v1.2.0
* @brief         Design widget main page, typesetting drinkwidget, realize purchase recharge operation.
* @author      senekit
* @date          2020-07-09
*/

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    QString  userName ;
    QString userPassword;
    enum Mode{refrigerator,heating,normal}mode;

    int tempature;
    int userMoney;
    int sumOfMoney;
    int numberOfBuy[10];
    int pirceOfDrinks[10];
    int tempOfDrinks[10];
    ResWidget* sigin;
    TCP_Client *p;
    void failToSignIn();
    void reminder();
    void successSignIn(QStringList array);
    void successRes(QStringList array);
    void failToRes(QStringList array);
signals:
    void drinksOfBuy(QString items);
    void numberOfChange1(int number);
    void numberOfChange2(int number);
    void numberOfChange3(int number);
    void numberOfChange4(int number);
    void numberOfChange5(int number);
    void numberOfChange6(int number);
    void RechargeOfUser(QString information);
    void reminderOfRe(QString information);

private slots:
    void on_spinBox_valueChanged(int arg1);

    void on_spinBox_2_valueChanged(int arg1);

    void on_spinBox_3_valueChanged(int arg1);

    void on_spinBox_4_valueChanged(int arg1);

    void on_spinBox_5_valueChanged(int arg1);

    void on_spinBox_6_valueChanged(int arg1);

    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void changeDb(QString information);

    void changeTemperature(QString temperature);

    void changeQuanit(QString information);



    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::Widget *ui;
    drinkwidget *drink[10];
};
#endif // WIDGET_H
