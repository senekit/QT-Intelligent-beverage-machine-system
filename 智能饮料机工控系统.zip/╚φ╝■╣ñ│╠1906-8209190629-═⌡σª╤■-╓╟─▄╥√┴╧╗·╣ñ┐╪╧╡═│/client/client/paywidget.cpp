#include "paywidget.h"
#include "ui_paywidget.h"
#include "netutil.h"


/**
* @projectName   client
* @class         PayWidget
* @version     v3.1.0
* @brief         生成支付窗口，生成支付二维码，支付成功时关闭窗口。
* @author      senekit
* @date          2020-07-15
*/

PayWidget::PayWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::PayWidget),
      server("http://writerfly.cn/service/pay/")
{
    ui->setupUi(this);
    this->moneyToPay = 0;
    query_timer = new QTimer(this);
    query_timer->setInterval(5000);
    connect(query_timer, SIGNAL(timeout()), this, SLOT(slotQueryIsPaid()));
}

PayWidget::~PayWidget()
{
    delete ui;
}

/**
 * @method  on_push_clicked()
 * @for PayWidget
 * @param{}
 * @return {void}
 * @brief  支付的槽函数
 */

void PayWidget::on_pushButton_clicked()
{
    QString fee = QString::number(ui->doubleSpinBox->value());

    QString param = "user_id=12345678&total_fee="+fee+"&purchase_type=1&attach=nothing&count=3";
    const QString url = server + "wxpay_pay.php?" + param;

    connect(new NetUtil(url), &NetUtil::finished, this, [=](QString s){
        qDebug() << "接口结果：" << s;


        QString payjs_order_id = NetUtil::extractOne(s, "\\[payjs_order_id\\]\\s*=>\\s*(\\S+)\\s*");
        QString qrcode = NetUtil::extractOne(s, "\\[qrcode\\]\\s*=>\\s*(\\S+)\\s*");
        QString return_code = NetUtil::extractOne(s, "\\[return_code\\]\\s*=>\\s*(\\S+)\\s*");

        if (return_code.trimmed() != "1")
        {
            QMessageBox::warning(this, "错误", "获取支付链接出错\n返回码：" + return_code);
            return ;
        }

        /**
         * SSL 出错的，需要安装 OpenSSL，拷贝安装目录的 ssleay32.dll 和 libeay32.dll 至运行目录或者 .../MinGW730_32/opt/bin/ 下
         */

        const QString path = QApplication::applicationDirPath() + "/wxpay.png";
        NetUtil* net = new NetUtil;
        net->download(qrcode, path);
        connect(net, &NetUtil::finished, this, [=](QString path){
            qDebug() << "二维码路径：" << path;
            ui->label->setText("");
            ui->label->setScaledContents(true);
            ui->label->setPixmap(QPixmap(path));
            net->deleteLater();
        });
        this->payjs_order_id = payjs_order_id;

        // 不断查询，直到支付成功
        query_timer->start();
    });
}


/**
 * 定时查询订单
 */
void PayWidget::slotQueryIsPaid()
{
    if (payjs_order_id.isEmpty())
        return ;

    const QString url = server + "pay_query.php?order_id=" + payjs_order_id;
    connect(new NetUtil(url), &NetUtil::finished, this, [=](QString s){
        qDebug() << "查询结果：" << s;


        QString return_code = NetUtil::extractOne(s, "\\[return_code\\]\\s*=>\\s*(\\S+)\\s*");
        if (return_code == "0") // 不存在订单
            return ;

        // 查看 paid 是不是 1，未支付时为0
        QString paid = NetUtil::extractOne(s, "\\[paid\\]\\s*=>\\s*(\\S+)\\s*");
        if (paid == "1")
        {
            query_timer->stop();
            ui->label->setPixmap(QPixmap());
            ui->label->setText("支付成功");
            QMessageBox::about(this,"成功","支付成功!");
            QString information = QString::number(10000*this->moneyToPay);
            emit RechargeInformation(information);
            payjs_order_id = "";
            this->close();
        }
    });
}


void PayWidget::on_doubleSpinBox_valueChanged(double arg1)
{
    this->moneyToPay = arg1;
}
