#include "tcp_client.h"
#include "ui_tcp_client.h"
#include <QHostAddress>
#include <QDateTime>
#include <QMessageBox>



TCP_Client::TCP_Client(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TCP_Client)
{
    ui->setupUi(this);

    /***    初始化TCP   ***/
    this->setWindowTitle("TCP客户端");
    this->isconnetion = false;
    //初始化sendMesSocket
    this->TCP_sendMesSocket = new QTcpSocket();

    //终止之前的连接，重置套接字
    TCP_sendMesSocket->abort();
    //给定IP和端口号，连接服务器
    this->TCP_sendMesSocket->connectToHost("127.0.0.1",666);

    //成功连接服务器的connected()信号连接到slot_connected() (注意：不是connect()信号)
    connect(TCP_sendMesSocket,SIGNAL(connected()),this,SLOT(slot_connected()));
    //发送按钮的clicked()信号连接到slot_sendmessage()
    connect(ui->pushButton_send,SIGNAL(clicked()),this,SLOT(slot_sendmessage()));
    //有新数据到达时的readyread()信号连接到slot_recvmessage()
    connect(TCP_sendMesSocket,SIGNAL(readyRead()),this,SLOT(slot_recvmessage()));
    //与服务器断开连接的disconnected()信号连接到slot_disconnect()
    connect(TCP_sendMesSocket,SIGNAL(disconnected()),this,SLOT(slot_disconnect()));
}

TCP_Client::~TCP_Client()
{
    delete ui;
}

//处理成功连接到服务器的槽
void TCP_Client::slot_connected()
{
    this->isconnetion = true;
    ui->textBrowser->append(tr("与服务器连接成功：") + QDateTime::currentDateTime().toString("yyyy-M-dd hh:mm:ss"));
}

//发送消息到服务器的槽
void TCP_Client::slot_sendmessage()
{
    if(this->isconnetion)
    {
        QString sendMessage = ui->lineEdit->text(); //从单行文本框获得要发送消息
        if(!sendMessage.isEmpty())
        {
            //发送消息到服务器
            this->TCP_sendMesSocket->write(sendMessage.toLatin1());
            //本地显示发送的消息
            QString localDispalyMessage = tr("send to server: ") + sendMessage \
                                            + QDateTime::currentDateTime().toString(" yyyy-M-dd hh:mm:ss") + tr("\n");
            ui->textBrowser->append(localDispalyMessage);
        }
        else
            QMessageBox::warning(this,"错误","消息不能为空!",QMessageBox::Ok);
    }
    else
        QMessageBox::warning(this,"错误","未连接到服务器!",QMessageBox::Ok);
       ui->lineEdit->clear();
}

void TCP_Client::slot_sendmessage1(QString item)
{
    if(this->isconnetion)
    {
        QString sendMessage = item; //从单行文本框获得要发送消息
        if(!sendMessage.isEmpty())
        {
            //发送消息到服务器
            this->TCP_sendMesSocket->write(sendMessage.toLatin1());
            //本地显示发送的消息
            QString localDispalyMessage = tr("send to server: ") + sendMessage \
                                            + QDateTime::currentDateTime().toString(" yyyy-M-dd-hh:mm:ss") + tr("\n");
            ui->textBrowser->append(localDispalyMessage);
        }
        else
            QMessageBox::warning(this,"错误","消息不能为空!",QMessageBox::Ok);
    }
    else
        QMessageBox::warning(this,"错误","未连接到服务器!",QMessageBox::Ok);

    ui->lineEdit->clear();
}


//接收来自服务器的消息的槽
void TCP_Client::slot_recvmessage()
{
    //接收来自服务器的消息
    QByteArray byteArray = this->TCP_sendMesSocket->readAll();
    emit informationOfServer(QString(byteArray));
    QString recvMessage = tr("recv from server: ") + byteArray + QDateTime::currentDateTime().toString(" yyyy-M-dd hh:mm:ss") + tr("\n");
    ui->textBrowser->append(recvMessage);
}



//取消与服务器连接的槽
void TCP_Client::slot_disconnect()
{
    QMessageBox::warning(this,"警告","与服务器的连接中断",QMessageBox::Ok);
    //关闭并随后删除socket
    TCP_sendMesSocket->close();
    TCP_sendMesSocket->deleteLater();
}



//    QDataStream in(&tcpSocket);//建立一个二进制流并绑定tcp套接字
//    if(nextBlockSize == 0)//判断是否按下确认
//    {
//        if(tcpSocket.bytesAvailable() < sizeof(quint16))//已接收的信息是否小于一个nextBlockSize 的大小
//            return;
//        in>>nextBlockSize;//将接受到的nextBlockSize写入nextBlockSize
//    }
//    if(tcpSocket.bytesAvailable() < nextBlockSize)//判断已接收的信息是否是一个完整的信息块
//        return;
//    quint8 type;
//    QString str, message;
//    in>>type>>str;//讲流中的数据写入本地
//    tcpSocket.close();//关闭tcp

//    /*对接受的到信息进行处理*/
//    if(type == quint8('L'))
//    {
//        message = "Login";
//        QMessageBox::information(this, message, "登陆成功");
//        MainWindow *w = new MainWindow;
//        w->show();
//        close();
//    }
//    else if(type == quint8('R'))
//    {
//        message = "Register";
//        QMessageBox::information(this, message, "注册成功");
//    }
//    else if(type == quint8('E'))
//    {
//        QMessageBox::warning(this, "Error", str);
//    }


