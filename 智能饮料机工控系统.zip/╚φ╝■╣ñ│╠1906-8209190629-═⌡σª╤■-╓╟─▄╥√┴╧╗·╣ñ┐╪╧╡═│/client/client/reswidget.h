#ifndef RESWIDGET_H
#define RESWIDGET_H

#include<QWidget>
#include<QLineEdit>

/**
* @projectName   client
* @class         reswidget
* @version     v2.1.0
* @brief         Design registration class, registration page to achieve registration
* @author      senekit
* @date          2020-07-12
*/

namespace Ui {
class ResWidget;
}

class ResWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ResWidget(QWidget *parent = nullptr);
    ~ResWidget();
    QLineEdit* userName;
    QLineEdit* password;

signals:
    void signIninformation(QString information);

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::ResWidget *ui;
};

#endif // RESWIDGET_H
