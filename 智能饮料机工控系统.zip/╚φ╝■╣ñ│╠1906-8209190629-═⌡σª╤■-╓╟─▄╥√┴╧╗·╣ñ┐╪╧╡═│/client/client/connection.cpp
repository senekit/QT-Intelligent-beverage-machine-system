#include "connection.h"
#include<QMessageBox>


connection::connection()
{

}
