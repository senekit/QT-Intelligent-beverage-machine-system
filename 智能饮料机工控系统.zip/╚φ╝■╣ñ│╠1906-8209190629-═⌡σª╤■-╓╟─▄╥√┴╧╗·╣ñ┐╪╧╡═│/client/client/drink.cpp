#include "drink.h"
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QDebug>


drink::drink()//Will not be called
{

//    QSqlQuery query("drink") ;

//  query.exec("select * from drinks");
//   // query.exec("update drinks set price = 2 where id = 5");
//    while(query.next())
//    {
//       qDebug()<<"111";
//        int id = query.value(0).toInt();
//        QString name = query.value(1).toString();
//        int price = query.value(2).toInt();
//        int quiant = query.value(3).toInt();
//      qDebug()<<id<<name<<price<<quiant;
//    }

}

/**
 * @method drink
 * @for drink
 * @param{int}tempid 饮料id
 * @return {}
 * @brief   从数据库中调出饮料相关数据
 */

drink::drink(int tempid)
{
    QString  findId = "select * from drinks where id = "+QString::number(tempid);
    QSqlQuery query("drink");
    query.exec(findId);
    query.next();
    this->id = query.value(0).toInt();
    this->name = query.value(1).toString();
    this->price = query.value(2).toInt();
    this->remainingQuanity = query.value(3).toInt();

}

/**
 * @method change
 * @for drink
 * @param {int}number 库存改变量
 * @return {void}
 * @brief   修改数据库中饮料的数量
 */

void drink::change(int number)//type
{

     QSqlQuery query("drink") ;
     this->remainingQuanity+=number;
     QString rqStr = QString::number(this->remainingQuanity);
     QString idStr = QString::number(this->id);
     query.exec("update drinks set  remainingQuantity="+rqStr+"  where id = "+idStr);
}

/**
 * @method updata
 * @for drink
 * @param{int} id
 * @return {void)
 * @brief 更新数据
 */



void drink::updata(int id)
{
    QString  findId = "select * from drinks where id = "+QString::number(id);
    QSqlQuery query("drink");
    query.exec(findId);
    query.next();
    this->id = query.value(0).toInt();
    this->name = query.value(1).toString();
    this->price = query.value(2).toInt();
    this->remainingQuanity = query.value(3).toInt();
}
