#ifndef  PAYWIDGET_H
#define PAYWIDGET_H
#include <QMainWindow>
#include <QMessageBox>
#include <QFileInfo>
#include <QTimer>
#include<QWidget>
#include "netutil.h"

/**
* @projectName   client
* @class         PayWidget
* @version     v3.1.0
* @brief         支付的界面
* @author      senekit(learn  from github)
* @date          2020-07-13
*/

QT_BEGIN_NAMESPACE
namespace Ui { class PayWidget; }
QT_END_NAMESPACE

class PayWidget : public QWidget
{
    Q_OBJECT

public:
    PayWidget(QWidget *parent = nullptr);
    ~PayWidget();
signals:
    void RechargeInformation(QString information);

private slots:
    void on_pushButton_clicked();

    void slotQueryIsPaid();

    void on_doubleSpinBox_valueChanged(double arg1);

private:
    Ui::PayWidget *ui;
    double moneyToPay;
    const QString server; // 后台服务网址
    QString payjs_order_id;
    QTimer* query_timer;
};
#endif // MAINWINDOW_H
