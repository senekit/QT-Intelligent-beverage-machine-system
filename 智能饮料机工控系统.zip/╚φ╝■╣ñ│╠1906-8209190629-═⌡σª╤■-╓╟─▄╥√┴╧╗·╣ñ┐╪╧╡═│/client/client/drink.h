#ifndef DRINK_H
#define DRINK_H
#include<QVector>

/**
* @projectName   client
* @class         drink
* @version     v1.0.0
* @brief         Design beverage category and query beverage inventory
* @author      senekit
* @date          2020-07-08
*/

class drink
{
public:
    drink();
    drink(int tempid);
    int id;
    QString name;
    int price;
    int remainingQuanity;
    bool isSale;
    void change(int number);
    void updata(int id);
};


#endif // DRINK_H
