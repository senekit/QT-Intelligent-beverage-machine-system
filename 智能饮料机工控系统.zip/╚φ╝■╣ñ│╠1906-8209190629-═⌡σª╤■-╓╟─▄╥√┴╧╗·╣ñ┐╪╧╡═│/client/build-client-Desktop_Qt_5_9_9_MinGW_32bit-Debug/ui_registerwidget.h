/********************************************************************************
** Form generated from reading UI file 'registerwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTERWIDGET_H
#define UI_REGISTERWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_registerWidget
{
public:

    void setupUi(QWidget *registerWidget)
    {
        if (registerWidget->objectName().isEmpty())
            registerWidget->setObjectName(QStringLiteral("registerWidget"));
        registerWidget->resize(400, 300);

        retranslateUi(registerWidget);

        QMetaObject::connectSlotsByName(registerWidget);
    } // setupUi

    void retranslateUi(QWidget *registerWidget)
    {
        registerWidget->setWindowTitle(QApplication::translate("registerWidget", "Form", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class registerWidget: public Ui_registerWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTERWIDGET_H
