#include "chartswidget.h"
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>
#include<QGraphicsView>
#include<QSqlQuery>
#include<QDebug>
#include<QDateTime>
QT_CHARTS_USE_NAMESPACE

/**
 * @method  ChartsWidget
 * @for          ChartsWidget
 * @param{QWidget} parent 父窗口
 * @return {}
 * @brief   生成图表的窗口
 */

ChartsWidget::ChartsWidget(QWidget *parent):QWidget(parent)
{

        int drink[40][10];
        for(int i=0;i<40;i++)
            for(int j=0;j<10;j++)
                drink[i][j]=0;

        QSqlQuery query("consumption") ;
        query.exec("select * from consumption");


        QDateTime dateTime;
        int month;
        int end = dateTime.currentDateTime().toString("dd").toInt();

        int begin = end - 7;
        while(query.next())
        {
         //  int id = query.value(0).toInt();
            QString name = query.value(1).toString();
            int drink1 = query.value(2).toInt();
            int drink2 = query.value(3).toInt();
            int drink3 = query.value(4).toInt();
            int drink4 = query.value(5).toInt();
            int drink5 = query.value(6).toInt();
            int drink6 = query.value(7).toInt();
            QString str = query.value(9).toString();
            QStringList array = str.split("-");
            month  = array[1].toInt();
            drink[array[2].toInt()][1]+=drink1;
            drink[array[2].toInt()][2]+=drink2;
            drink[array[2].toInt()][3]+=drink3;
            drink[array[2].toInt()][4]+=drink4;
            drink[array[2].toInt()][5]+=drink5;
            drink[array[2].toInt()][6]+=drink6;
            qDebug()<<array[0]<<array[1]<<array[3];
        }

    QBarSet *set0 = new QBarSet("drink1");
    QBarSet *set1 = new QBarSet("drink2");
    QBarSet *set2 = new QBarSet("drink3");
    QBarSet *set3 = new QBarSet("drink4");
    QBarSet *set4 = new QBarSet("drink5");
    QBarSet *set5 = new QBarSet("drink6");


    QStringList categories;
    //categories << "Jan" << "Feb" << "Mar" << "Apr" << "May" << "Jun";

    for(int i=begin;i<end;i++)
    {
        categories<<QString::number(month)+"/"+QString::number(i);
        *set0 <<drink[i][1];
        *set1 <<drink[i][2];
        *set2 <<drink[i][3];
        *set3 <<drink[i][4];
        *set4 <<drink[i][5];
        *set5 <<drink[i][6];
     }
//        *set0 << 1 << 2 << 3 << 4 << 5 << 6;// Jane 6个月份的值
//        *set1 << 5 << 0 << 0 << 4 << 0 << 7;
//        *set2 << 3 << 5 << 8 << 100<< 8 << 5;
//        *set3 << 5 << 6 << 7 << 3 << 4 << 5;
//        *set4 << 9 << 7 << 5 << 3 << 1 << 2;
//        *set5 << 5 << 6 << 7 << 3 << 4 << 5;
//![1]

//![2]
    QBarSeries *series = new QBarSeries();
    series->append(set0);
    series->append(set1);
    series->append(set2);
    series->append(set3);
    series->append(set4);
    series->append(set5);

//![2]

//![3]
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("chart of drinks");
    chart->setAnimationOptions(QChart::SeriesAnimations);
//![3]

//![4]

    QBarCategoryAxis *axis = new QBarCategoryAxis();
    axis->append(categories);
    chart->createDefaultAxes();//创建默认的左侧的坐标轴（根据 QBarSet 设置的值）
    chart->setAxisX(axis, series);//设置坐标轴
//![4]

//![5]
    chart->legend()->setVisible(true); //设置图例为显示状态
    chart->legend()->setAlignment(Qt::AlignBottom);//设置图例的显示位置在底部
//![5]

//![6]
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
//![6]
 //  QGraphicsView *charVie = new QGraphicsView(this);
//![7]
    chartView->setParent(this);
    chartView->setGeometry(0,0,700,700);
    chartView->resize(700,700);
    this->resize(700, 700);
    this->show();

}

ChartsWidget::~ChartsWidget()
{

}
