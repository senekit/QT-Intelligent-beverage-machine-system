#include "dealcommit.h"

dealCommit::dealCommit()
{

}
