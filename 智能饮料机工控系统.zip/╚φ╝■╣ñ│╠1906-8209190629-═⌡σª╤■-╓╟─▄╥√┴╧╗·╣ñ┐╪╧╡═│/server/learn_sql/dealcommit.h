#ifndef DEALCOMMIT_H
#define DEALCOMMIT_H
#include<QString>

class dealCommit
{

public:
    dealCommit();

private slots:
    void dealCommit();


};

#endif // DEALCOMMIT_H
