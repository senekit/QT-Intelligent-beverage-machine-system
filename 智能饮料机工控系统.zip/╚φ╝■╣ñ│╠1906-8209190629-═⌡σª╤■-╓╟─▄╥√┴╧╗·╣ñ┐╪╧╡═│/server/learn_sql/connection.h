#ifndef CONNECTION_H
#define CONNECTION_H
#include<QMessageBox>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QDebug>

/**
* @projectName   learn_sql
* @class         createconnection
* @version     v2.1
* @brief         实现数据库的连接
* @author      senekit
* @date          2020-07-09
*/

static bool createConnection()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("my.db");
    if(!db.open())
    {
        QMessageBox::critical(0,"can't open database","unable to establish a database connection",QMessageBox::Cancel);
        return false;
     }

  //  QSqlQuery query;
   // query.exec(QString("create table stu (id int ,name varchar,course int)"));
    //query.exec(QString("create table csu (id int primary key,name varchar,course int)"));
//    query.exec(QString("create table stu (id int primary key, "
//                       "name varchar, course int)"));
//    query.exec(QString("create table user ( id int primary key ,"
//                       "name varchar, password varchar)"));
   // query.exec(QString("insert into stu values(1, 'jo', 11)"));
   // query.exec(QString("insert into stu values(2, '马', 11)"));
   // query.exec(QString("insert into stu values(3, '孙', 12)")); qDebug()<<"1111"<<endl;

    return true;
}

#endif // CONNECTION_H
