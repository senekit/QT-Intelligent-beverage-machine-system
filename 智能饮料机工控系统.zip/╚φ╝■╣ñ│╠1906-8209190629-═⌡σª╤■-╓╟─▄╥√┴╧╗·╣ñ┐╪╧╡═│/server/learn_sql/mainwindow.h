#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QSqlTableModel>
#include<server.h>
#include"spider.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

/**
* @projectName   learn_sql
* @class         MainWindow
* @version     v2.0.0
* @brief         服务端主页面
* @author      senekit
* @date          2020-07-13
*/

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    int id;
    server *p;
    spider *weather;
signals:
    void siginStatus(QString message);
private slots:

    void changeDb(QString information);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_spinBox_valueChanged(int arg1);

     void setWeather(QString information);

     void on_pushButton_9_clicked();

private:

    void changeQuanit(QStringList array);
    void addBalance(QStringList array);
    void buyAction(QStringList array);
    void siginInAction(QStringList array);
    void resgiter(QStringList array);
    void remind(QStringList array);
    Ui::MainWindow *ui;
    QString tempTable;
    QSqlTableModel *model;
};
#endif // MAINWINDOW_H
