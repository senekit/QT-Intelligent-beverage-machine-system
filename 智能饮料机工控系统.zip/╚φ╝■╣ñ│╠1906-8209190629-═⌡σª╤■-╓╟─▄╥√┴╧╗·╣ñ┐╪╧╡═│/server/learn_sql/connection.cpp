#include "connection.h"

connection::connection()
{

}
