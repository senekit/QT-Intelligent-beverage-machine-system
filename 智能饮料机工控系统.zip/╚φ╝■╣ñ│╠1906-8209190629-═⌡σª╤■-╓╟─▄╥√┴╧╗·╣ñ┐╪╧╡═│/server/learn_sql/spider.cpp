
#include "spider.h"
#include<QTextCodec>

/**
 * @method spider
 * @for  spider
 * @param{parent}
 * @return {}
 * @brief spider初始化
 */

spider::spider(QWidget *parent):QWidget(parent)
{
     QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
     manage = new QNetworkAccessManager(this);
     QNetworkRequest networkRequest;
     networkRequest.setUrl(QUrl("http://wthrcdn.etouch.cn/weather_mini?citykey=101091007"));//citykey 即 cityid
     connect(manage,SIGNAL(finished(QNetworkReply *)),this,SLOT(getInformation(QNetworkReply*)));
     manage->get(networkRequest);
}

spider::~spider()
{

}

/**
 * @method getInformation
 * @for   spider
 * @param{QNetworkReply}reply
 * @return {void}
 * @brief  将网页的reply由byteArray到Qstring
 */

void spider::getInformation(QNetworkReply *reply)
{
    QVariant status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute);
    if(reply->error()==QNetworkReply::NoError)
    {
        bytes = reply ->readAll();
        QString str(bytes);
        InformationOfCity = str;
        init(str);
      //  qDebug()<<str;
    }
    reply->deleteLater();
}

/**
 * @method
 * @for spider
 * @param{QString} str 网页源码
 * @return {void}
 * @brief  提取关键信息
 */

void spider::init(QString str)
{
    QByteArray byteArray;
    QJsonParseError jsonError;
    QJsonDocument document = QJsonDocument::fromJson(byteArray.append(str),&jsonError);
    if(jsonError.error == QJsonParseError::NoError)
    {
        QJsonObject object = document.object();
        QJsonValue value = object.take("desc");//对象的值
        if(value.toString()!="OK")
         {
            QMessageBox::warning(this,"抱歉","暂无此城市的天气情况",QMessageBox::Ok,QMessageBox::Ok);
            return;
         }
        else
        {
            QJsonValue dataOfObject = object.take("data");
            this->data.ganmao = dataOfObject.toObject().take("ganmao").toString();
            this->data.wendu = dataOfObject.toObject().take("wendu").toString();
            this->data.city = dataOfObject.toObject().take("city").toString();
            emit weatherCondition(data.city+"/"+data.wendu+"/"+data.ganmao);
        }
  //  qDebug()<<this->data.wendu;
    }

}
