#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QTableView>
#include<QDebug>
#include<QMessageBox>
#include<QSqlRelationalTableModel>
#include<QSqlError>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QTextCodec>
#include"connection.h"
#include"server.h"
#include"spider.h"
#include"chartswidget.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)

{
   // this->setWindowTitle("client");
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
   if (!createConnection()) return;
//    this->resize(500,600);
 //  qDebug()<<weather->data.wendu;

    weather = new spider(nullptr);
    p = new server(nullptr);
    p->hide();
    connect(weather,SIGNAL(weatherCondition(QString)),this,SLOT(setWeather(QString)));
    connect(p,SIGNAL(informationOfClient(QString )),this,SLOT(changeDb(QString)));
    connect(this,SIGNAL(siginStatus(QString)),p,SLOT(slotSendmessage1(QString)),Qt::QueuedConnection);
    id = 1;
//    p->show();
    ui->setupUi(this);
    model = new QSqlTableModel(this);
    tempTable = "user";
    model->setTable("user");
    model->select();
    this->ui->spinBox->setValue(20);
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    ui->tableView->setModel(model);
    this->setWindowTitle("Server");
}

MainWindow::~MainWindow()
{
    delete ui;
}

/**
 * @method  setWeather
 * @for MainWindow
 * @param{QString} message 爬虫发送来的字符串
 * @return {void}
 * @brief  设置天气信息
 */

void MainWindow::setWeather(QString message)
{
    //qDebug()<<message;
    QStringList  array  = message.split("/");
    this->ui->label_3->setText("位置:"+array[0]+"\n温度:"+array[1]+"℃\n建议:"+array[2]);
}

/**
 * @method on_pushButton_clicked
 * @for MainWindow
 * @param{}
 * @return {void}
 * @brief  提交修改
 */

void MainWindow::on_pushButton_clicked()
{
    model->database().transaction();
    if(model->submitAll())
    {
        model->database().commit();
    }
    else
     {
        model->database().rollback();
        QMessageBox::warning(this,tr("tableModel"),tr("数据库有误%1").arg(model->lastError().text()));
    }
}

/**
 * @method on_pushButton_2_clicked
 * @for MainWindow
 * @param{}
 * @return {void}
 * @brief  撤回
 */

void MainWindow::on_pushButton_2_clicked()
{
    model->revertAll();
}

/**
 * @method on_pushButton_3_clicked
 * @for MainWindow
 * @param{}
 * @return {void}
 * @brief  增加一行
 */

void MainWindow::on_pushButton_3_clicked()
{
    int rowNum = model->rowCount();
    id = rowNum+1;
    model->insertRow(rowNum);
    model->setData(model->index(rowNum,0), id);
    model->submitAll();
}

/**
 * @method on_pushButton_4_clicked
 * @for MainWindow
 * @param{}
 * @return {void}
 * @brief  删除
 */

void MainWindow::on_pushButton_4_clicked()
{
    int curRow = ui->tableView->currentIndex().row();
    model->removeRow(curRow);
    model->submitAll();
}

/**
 * @method on_pushButton_7_clicked
 * @for MainWindow
 * @param{}
 * @return {void}
 * @brief  查找
 */

void MainWindow::on_pushButton_7_clicked()
{
     QString name = ui->lineEdit->text();
     model->setFilter(QString("id='%1' ").arg(name));
     model->select();
}

/**
 * @method on_pushButton_8_clicked
 * @for MainWindow
 * @param{}
 * @return {void}
 * @brief  切换表
 */

void MainWindow::on_pushButton_8_clicked()
{
    model->setTable(tempTable);
    model->select();
}

/**
 * @method on_pushButton_5_clicked
 * @for MainWindow
 * @param{}
 * @return {void}
 * @brief  用户信息
 */

void MainWindow::on_pushButton_5_clicked()
{
    tempTable = "user";
    model->setTable(tempTable);
    model->select();
}

/**
 * @method on_pushButton_6_clicked
 * @for MainWindow
 * @param{}
 * @return {void}
 * @brief  消费记录
 */

void MainWindow::on_pushButton_6_clicked()
{
    tempTable = "consumption";
    model->setTable(tempTable);
    model->select();
}

/**
 * @method  changeDb
 * @for MainWindow
 * @param{QString information} 客户端的information
 * @return {void}
 * @brief 确定接收到信息后服务端下一步的操作
 */

void MainWindow::changeDb(QString information)
{
    QStringList array= information.split("/");
//    for(int i =0;i<array.size();i++)
//            qDebug()<<array[i];
    if(array[0]=="B")this->buyAction(array);
    if(array[0]=="S")this->siginInAction(array);
    if(array[0]=="R")this->resgiter(array);
    if(array[0]=="RE")this->addBalance(array);
    if(array[0]=="Replenishment")this->remind(array);
}

/**
 * @method remind
 * @for MainWindow
 * @param{QStringList}  array 饮料
 * @return {void}
 * @brief 提醒补货
 */

void MainWindow::remind(QStringList array)
{
    QString drink ="";
    for(int i=1;i<array.size();i++)
    {
        drink = drink +"\n "+array[i];
    }
    drink=drink+"\n需要补货";
    QMessageBox::about(this,"补货通知",drink);
}

/**
 * @method on_spinBox_valueChanged
 * @for MainWindow
 * @param{int }arg1 温度
 * @return {void}
 * @brief 实时修改客户端的温度
 */

void MainWindow::buyAction(QStringList array)
{
 //   if(!createConnection())qDebug()<<"111";
    tempTable = "consumption";
    model->setTable(tempTable);
    model->select();
    int rowNum = model->rowCount();
    id = rowNum+1;
    model->insertRow(rowNum);
    model->setData(model->index(rowNum,0), id);
    model->setData(model->index(rowNum,1),array[1]);
    model->setData(model->index(rowNum,2),array[3]);
    model->setData(model->index(rowNum,3),array[4]);
    model->setData(model->index(rowNum,4),array[5]);
    model->setData(model->index(rowNum,5),array[6]);
    model->setData(model->index(rowNum,6),array[7]);
    model->setData(model->index(rowNum,7),array[8]);
    model->setData(model->index(rowNum,8),array[9]);
    model->setData(model->index(rowNum,9),array[2]);
    model->submitAll();
    this->changeQuanit(array);

}


/**
 * @method on_spinBox_valueChanged
 * @for MainWindow
 * @param{int }arg1 温度
 * @return {void}
 * @brief 实时修改客户端的温度
 */

void MainWindow::on_spinBox_valueChanged(int arg1)
{
    QString message = "T/"+QString::number(arg1);
    this->p->sendMessage(message);
}
void MainWindow::siginInAction(QStringList array)
{
    QString user = array[1];
    QString password  = array[2];
//    tempTable = "user";
//    model->setTable(tempTable);
    QString  findUser = "select * from user where user = "+user;
    QSqlQuery query("user");
    query.exec(findUser);
    query.next();
    QString passwordRight  = query.value(2).toString();
    int quanity = query.value(3).toInt();
    //qDebug()<<passwordRight<<" "<<quanity;
    if(passwordRight == password)
    {
        QString message="S/"+user+"/"+QString::number(quanity);
        emit siginStatus(message);
    }
    else
    {
        QString message="F";
        emit siginStatus(message);
    }
}

/**
 * @method  resgiter
 * @for  MainWindow
 * @param{QStringList}array
 * @return {}
 * @brief 注册
 */

void MainWindow::resgiter(QStringList array)
{
    QString user = array[1];//用户名
    int quanity = 0;
    tempTable = "user";//表名
    model->setTable(tempTable);//设置当前表为user
    model->select();
    int rowNum = model->rowCount();

    QString  findUser = "select * from user where user = "+user;//判断是否有同名用户
    QSqlQuery query("user");
    query.exec(findUser);
    query.next();
    QString passwordRight  = query.value(2).toString();
    if(passwordRight!="")
    {
        QString message="FR/"+user+"/"+QString::number(quanity);
        emit siginStatus(message);
        return;
    }

    id = rowNum+1;//表中新增一行
    model->insertRow(rowNum);
    model->setData(model->index(rowNum,0), id);//第一列是id
    model->setData(model->index(rowNum,1),array[1]);//第二列是name
    model->setData(model->index(rowNum,2),array[2]);//第三列是密码
    model->setData(model->index(rowNum,3),0);//余额
    model->submitAll();
    QString message="SR/"+user+"/"+QString::number(quanity);
    emit siginStatus(message);
}

/**
 * @method  changeQuanit
 * @for      MainWindow
 * @param{QStringList}array
 * @return {void}
 * @brief  减少用户余额
 */

void MainWindow::changeQuanit(QStringList array)
{
//        QSqlQuery query  ("my");
//        query.exec("select * from user where user = "+array[1]);
//        int balance = query.value(1).toInt();
    QString user = array[1];
//    tempTable = "user";
//    model->setTable(tempTable);
    QString  findUser = "select * from user where user = "+user;
    QSqlQuery query("user");
    query.exec(findUser);
    query.next();
    int balance = query.value(3).toInt();
    qDebug()<<query.value(0).toString()<<" "<<query.value(1).toString()<<" "<<query.value(2).toString()<<" "<<query.value(3).toString();
    query.exec("update user set balance = "+QString::number(balance-array[10].toInt())+" where user = "+array[1]);
}

/**
 * @method  addBalance
 * @for      MainWindow
 * @param{QStringList}array
 * @return {void}
 * @brief  充值用户余额
 */

void MainWindow::addBalance(QStringList array)
{
    QString user = array[1];
//    tempTable = "user";
//    model->setTable(tempTable);
    QString  findUser = "select * from user where user = "+user;
    QSqlQuery query("user");
    query.exec(findUser);
    query.next();
    int balance = query.value(3).toInt();
    //qDebug()<<query.value(0).toString()<<" "<<query.value(1).toString()<<" "<<query.value(2).toString()<<" "<<query.value(3).toString();
    query.exec("update user set balance = "+QString::number(balance+array[2].toInt())+" where user = "+array[1]);
    model->select();
}


/**
 * @method on_pushButton_9_clicked
 * @for MainWindow
 * @param{}
 * @return {void}
 * @brief 生成图表
 */

void MainWindow::on_pushButton_9_clicked()
{
    ChartsWidget *chartWindow = new ChartsWidget(nullptr);
    chartWindow->setWindowTitle("chart");
    chartWindow->show();
}
