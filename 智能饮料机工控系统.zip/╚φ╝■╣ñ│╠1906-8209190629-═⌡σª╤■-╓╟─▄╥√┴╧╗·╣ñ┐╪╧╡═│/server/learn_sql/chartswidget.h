#ifndef CHARTSWIDGET_H
#define CHARTSWIDGET_H
#include<QWidget>

/**
* @projectName   learn_sql
* @class         chartswidget
* @version     v3.2.0
* @brief          生成图表
* @author      senekit
* @date          2020-07-15
*/

class ChartsWidget: public QWidget
{
public:
    ChartsWidget(QWidget* parent = nullptr);
    ~ChartsWidget();
};

#endif // CHARTSWIDGET_H
