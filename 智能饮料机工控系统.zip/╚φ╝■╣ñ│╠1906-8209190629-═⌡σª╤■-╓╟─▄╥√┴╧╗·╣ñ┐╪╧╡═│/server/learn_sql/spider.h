#ifndef SPIDER_H
#define SPIDER_H

#include <QMainWindow>
#include <QPushButton>
#include <QtNetwork/QNetworkReply>
#include <QtNetwork/QNetworkAccessManager>
#include <QLabel>
#include <QTextCodec>
#include <QByteArray>
#include <QtNetwork/QNetworkRequest>
#include <QJsonParseError>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QMessageBox>
#include <QHBoxLayout>
#include <QJsonArray>

/**
* @projectName   learn_sql
* @class         Spider
* @version     v3.1.0
* @brief         爬取当地的天气
* @author      senekit
* @date          2020-07-14
*/

struct DATA{
    QString ganmao;
    QString wendu;
    QString city;
};

class spider:public QWidget
{
    Q_OBJECT
public:
    spider(QWidget *parent = nullptr);
    ~spider();
    DATA data;
    QString InformationOfCity;
    QByteArray bytes;
    QNetworkAccessManager *manage;
signals:
     void weatherCondition(QString);
public slots:
    void getInformation(QNetworkReply *reply);
    void init(QString str);


};

#endif // SPIDER_H
