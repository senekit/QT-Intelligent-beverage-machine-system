#include "server.h"
#include "ui_server.h"
#include <QMessageBox>
#include <QDateTime>

server::server(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::server)
{
    ui->setupUi(this);

    //初始化
    TCPserver = new QTcpServer();
    TCPconnectSocket = nullptr;
    connect(ui->pushButton_send,SIGNAL(clicked()),this,SLOT(slotSendmessage()));

    //调用listen函数监听同时绑定IP和端口号
    if(TCPserver->listen(QHostAddress::LocalHost,666)) //判断listen是否成功，成功则继续执行，连接新接收信号槽
    {
        this->connect(TCPserver,SIGNAL(newConnection()),this,SLOT(slotNewconnect()));  //将服务器的新连接信号连接到接收新连接的槽
    }
    else
    {
        QMessageBox::critical(this,"错误","IP绑定错误，请关闭其它服务端或更改绑定端口号");
    }
}

server::~server()
{
    delete ui;
}

//建立新连接的槽
void server::slotNewconnect()
{
    if(TCPserver->hasPendingConnections())  //查询是否有新连接
    {
        TCPconnectSocket = TCPserver->nextPendingConnection(); //获取与真实客户端相连的客户端套接字
        ui->textBrowser->append("client login!"); //若有新连接，则提示

        this->connect(TCPconnectSocket,SIGNAL(readyRead()),this,SLOT(slotRecvmessage())); //连接客户端的套接字的有新消息信号到接收消息的槽
        this->connect(TCPconnectSocket,SIGNAL(disconnected()),this,SLOT(slotDisconnect())); //连接客户端的套接字取消连接信号到取消连接槽
    }
}

//发送消息的槽
void server::slotSendmessage()
{
    QString sendMessage = ui->lineEdit->text(); //获取单行文本框内要发送的内容
    if(TCPconnectSocket != nullptr && !sendMessage.isEmpty()) //确保有客户端连接，并且发送内容不为空
    {
        TCPconnectSocket->write(sendMessage.toLatin1());   //发送消息到客户端

        QString localDispalyMessage = "send to client: " + sendMessage \
                        + QDateTime::currentDateTime().toString(" yyyy-M-dd hh:mm:ss") + tr("\n");
        ui->textBrowser->append(localDispalyMessage);   //将要发送的内容显示在listwidget
    }

    ui->lineEdit->clear();
}

//接收消息的槽
void server::slotRecvmessage()
{
    if(TCPconnectSocket != nullptr) //与客户端连接的socket，不是nullptr，则说明有客户端存在
    {
        QByteArray array = TCPconnectSocket->readAll();    //接收消息
        QHostAddress clientaddr = TCPconnectSocket->peerAddress(); //获得IP
        int port = TCPconnectSocket->peerPort();   //获得端口号

        QDateTime datetime = QDateTime::currentDateTime();

//        QString sendMessage = tr("recv from :") + clientaddr.toString() + tr(" : ") \
//                                + QString::number(port) + tr("   ") + datetime.toString("yyyy-M-dd hh:mm:ss") + tr("\n");
//        sendMessage += array;
        //qDebug()<<array;
        //qDebug()<<"1111111111111111111111111111";
        emit informationOfClient(array);
//        ui->textBrowser->append(sendMessage);   //将接收到的内容加入到listwidget
    }

}

//取消连接的槽
void server::slotDisconnect()
{
    if(TCPconnectSocket != nullptr)
    {
        ui->textBrowser->append("client logout!");
        TCPconnectSocket->close(); //关闭客户端
        TCPconnectSocket->deleteLater();
    }
}
//send message

void server::sendMessage(QString message)
{
    QString sendMessage = message;
    if(TCPconnectSocket != nullptr && !sendMessage.isEmpty()) //确保有客户端连接，并且发送内容不为空
    {
        TCPconnectSocket->write(sendMessage.toLatin1());   //发送消息到客户端

//        QString localDispalyMessage = "send to client: " + sendMessage \
//                        + QDateTime::currentDateTime().toString(" yyyy-M-dd hh:mm:ss") + tr("\n");
//        ui->textBrowser->append(localDispalyMessage);   //将要发送的内容显示在listwidget
    }

}

void server::slotSendmessage1(QString message)
{
    QString sendMessage = message;
    qDebug()<<message;
    if(TCPconnectSocket != nullptr && !sendMessage.isEmpty()) //确保有客户端连接，并且发送内容不为空
    {
        TCPconnectSocket->write(sendMessage.toLatin1());   //发送消息到客户端

//        QString localDispalyMessage = "send to client: " + sendMessage \
//                        + QDateTime::currentDateTime().toString(" yyyy-M-dd hh:mm:ss") + tr("\n");
//        ui->textBrowser->append(localDispalyMessage);   //将要发送的内容显示在listwidget
    }
}





