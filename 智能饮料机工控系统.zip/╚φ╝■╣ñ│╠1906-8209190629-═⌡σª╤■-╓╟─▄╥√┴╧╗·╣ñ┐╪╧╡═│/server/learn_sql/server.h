#ifndef SERVER_H
#define SERVER_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>

/**
* @projectName   learn_sql
* @class         server
* @version     v2.1.1
* @brief          tcp服务端
* @author      senekit
* @date          2020-07-10
*/

namespace Ui {
class server;
}

class server : public QWidget
{
    Q_OBJECT

public:
    explicit server(QWidget *parent = nullptr);
    ~server();
    void sendMessage(QString message);
signals:
    void informationOfClient(QString information);


private slots:
    void slotNewconnect(); //建立新连接的槽
    void slotSendmessage(); //发送消息的槽
    void slotRecvmessage(); //接收消息的槽
    void slotDisconnect(); //取消连接的槽
    void slotSendmessage1(QString message);

private:
    Ui::server *ui;
    QTcpServer *TCPserver; //QTcpServer服务器
    QTcpSocket *TCPconnectSocket; //与客户端连接套接字
};

#endif // SERVER_H
